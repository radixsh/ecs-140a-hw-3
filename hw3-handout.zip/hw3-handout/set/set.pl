isUnion(Set1,Set2,Union) :-
    %% remove fail and add body/other cases for this predicate
    fail.

isIntersection(Set1,Set2,Intersection) :-
    %% remove fail and add body/other cases for this predicate
    fail.

isEqual(Set1,Set2) :-
    %% remove fail and add body/other cases for this predicate
    fail.
